import sys
import matplotlib.pyplot as plt
import numpy as np


def simulate_regime_change(stdev, output_filename, plot=False):
    '''Simulate two adjacent regimes.

    XY data, collected every minute of the day, where Y in linearly
    dependent on X with some noise, and

    Presuming a regime shift at minute of the day change_minute, the regimes may be characterized by
    where `e` is a normal distribution of errors characterized by a standard deviation `s` that is
    constant throughout the day:

        Y1 = a1 * X1 + b1 + e(s) for minute of day < change_minute
        Y2 = a2 * X2 + b2 + e(s) for minute of day >= change_minute

    The regime change happens between 06:00 and 18:00 i.e. `360 <= changeMinute <= 1080`.

    The X data is produced uniformly on the half-open interval [0.0, 1.0). The gradients and
    intercepts are chosen uniformly from the half-open intervals [0.0, gradient_upper_bound) and
    [0.0, intercept_upper_bound) respectively.

    Arguments:
        stdev [float]:
            the standard deviation of the normal distribution of errors (NB: must be greater than 0)
        output_filename [string]:
            the filename you want to write to
        plot [boolean]:
            if passed, plot the two regimes.

    Returns:
        change_minute, X, Y
    '''
    series_length = 1440
    gradient_upper_bound = 1.0
    intercept_upper_bound = 0.1

    # Parameterize regimes
    a1, a2 = gradient_upper_bound * np.random.random(2)
    b1, b2 = intercept_upper_bound * np.random.random(2)
    change_minute = np.random.randint(
            np.around(series_length / 4.0), np.around(3 * series_length / 4.0))

    # Populate regimes
    regime1_x = np.random.random(change_minute)
    regime2_x = np.random.random(series_length - change_minute)
    regime1_y = a1 * regime1_x + b1 + np.random.normal(loc=0, scale=stdev, size=len(regime1_x))
    regime2_y = a2 * regime2_x + b2 + np.random.normal(loc=0, scale=stdev, size=len(regime2_x))

    # Output
    if plot:
        plt.plot(regime1_x, regime1_y, 'r.', label='regime1')
        plt.plot(regime2_x, regime2_y, 'b.', label='regime2')
        plt.legend()
        plt.savefig('{}.png'.format(output_filename))

    x = np.hstack([regime1_x, regime2_x])
    y = np.hstack([regime1_y, regime2_y])

    header = '# series_length={:d}, stdev={:.2e}\n'.format(series_length, stdev)
    header += '# a1={:.2e}, b1={:.2e}, a2={:.2e}, b2={:.2e}\n'.format(a1, b1, a2, b2)
    header += '# Regime shift at minute {:d}\n'.format(change_minute)
    output_file = open(output_filename, 'w')
    output_file.write(header)
    output_file.writelines(['{:.3e} {:.3e}\n'.format(_x, _y) for _x, _y in zip(x, y)])
    output_file.close()

    return change_minute, x, y


if __name__ == '__main__':
    ''' Simulate a regime change.

    Usage:
        python simulate-regime-change.py 0.01 xy.dat, or
        python simulate-regime-change.py 0.01 xy.dat plot
    '''
    if len(sys.argv) <= 2:
        raise ValueError('Invalid arguments: please see inline documentation')
    simulate_regime_change(float(sys.argv[1]), *sys.argv[2:])
