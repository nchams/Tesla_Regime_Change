REGIME CHANGE CODING CHALLENGE
====================================================================================================
The following is an exercise in algorithm development and coding. You should provide a simple
working solution which others could easily use and extend. Write your algorithm in Python 
and use only commonly available libraries.

Please don't spend more than a few hours on the exercise. Please send your solution by email within
24 hours of downloading the challenge.


BACKGROUND
====================================================================================================
Presume that every minute of the day we measure two variables X and Y which are linearly dependent.
Now imagine that at some minute of the day, change_minute, there is a 'regime change' in which the
underlying model changes. The situation can summarized as follows:

    Y1 = a1 * X1 + b1 + e(s) for minute of the day <  change_minute
    Y2 = a2 * X2 + b2 + e(s) for minute of the day >= change_minute

Here e is a normal distribution of errors characterized by a standard deviation `s` that is constant
throughout the day. To simplify matters, you may assume that the regime change happens
between 06:00 and 18:00, i.e. `360 <= change_minute <= 1080`.


CHALLENGE
====================================================================================================
Write an algorithm to determine `change_minute` as accurately as possible from the 10 sample input
files with `s=0.01`.

Time permitting, extend your consideration to larger standard deviations, in particular `s=0.5`.


INCLUDED FILES AND SETUP
====================================================================================================
The following samples are provided:

* _examples/xy-0.01-*.dat_ : random samples with `s=0.01`
* _examples/xy-0.5-*.dat_ : random samples with `s=0.5`

The header of each sample data file includes parameters to help you get started but your solution
should not rely on these numbers!

If you wish you can generate more samples using the script _simulate-regime-change.py_. To do so you need
to install NumPy and Matplotlib.

This file has been tested on Python >3.6, Numpy 1.6.1, and Matplotlib 1.1.1rc.


YOUR ANSWER
====================================================================================================
Terse simplicity should be favored over complete complexity. Defensive coding against malformed
inputs is not required. Your code should be easily accessible to others but you should bear in mind
that well written code only requires sparse documentation.

It should be possible to run your code as:

    ./executable input-file.dat

As a minimum your code should output the following to stdout:

    actual_change_minute = 612 , calculated_change_minute = 580 , residual_change_minute = -32

Please provide your solution as an archive containing:

* source code
* _results-0.01.dat_ containing your results for `s=0.01`, and similarly for `s=0.5`
* any other information you'd like to share such as:
    * additional information on how to run the code
    * design decisions that you made
    * ways in which your solution could be improved
